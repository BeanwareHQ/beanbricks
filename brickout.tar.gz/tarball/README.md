## brickout.c

A questionable brick-out/breakout clone in C and Raylib.

## Dependencies

 * Raylib

## Building

 * `make`

## Running

 * `./brickout`

## Changing Settings

Go through the options and comments found in `settings.h`. Change the `#define`s as you wish, and recompile by running `make`.
